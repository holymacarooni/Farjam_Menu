export const menuCategories = [
  {
    id: 'coffee',
    name: 'قهوه',
    icon: '☕',
    items: [
      {
        id: 'espresso',
        name: 'اسپرسو',
        ingredients: 'اسپرسو',
        price: 123,
        image: '/images/espresso.jpg'
      },
      {
        id: 'americano',
        name: 'آمریکانو',
        ingredients: 'اسپرسو، آب',
        price: 107,
        image: '/images/americano.jpg'
      },
      {
        id: 'cappuccino',
        name: 'کاپوچینو',
        ingredients: 'اسپرسو، شیر، فوم شیر',
        price: 135,
        image: '/images/cappuccino.jpg'
      },
      {
        id: 'latte',
        name: 'کافه لاته',
        ingredients: 'اسپرسو، شیر، فوم شیر',
        price: 145,
        image: '/images/latte.jpg'
      },
      {
        id: 'caramel-macchiato',
        name: 'کارامل ماکیاتو',
        ingredients: 'اسپرسو، شیر، سیروپ کارامل',
        price: 171,
        image: '/images/caramel-macchiato.jpg'
      },
      {
        id: 'mocha',
        name: 'موکا',
        ingredients: 'اسپرسو، شیر، شکلات',
        price: 171,
        image: '/images/mocha.jpg'
      },
      {
        id: 'v60',
        name: 'قهوه دمی V60',
        ingredients: 'قهوه دمی V60',
        price: 167,
        image: '/images/v60.jpg'
      },
      {
        id: 'chemex',
        name: 'قهوه کمکس 350ml',
        ingredients: 'قهوه کمکس',
        price: 221,
        image: '/images/chemex.jpg'
      },
      {
        id: 'turkish-coffee',
        name: 'قهوه ترک / پرشین',
        ingredients: 'قهوه ترک',
        price: 115,
        image: '/images/turkish-coffee.jpg'
      },
      {
        id: 'affogato',
        name: 'آفوگاتو',
        ingredients: 'اسپرسو، بستنی',
        price: 147,
        image: '/images/affogato.jpg'
      },
      {
        id: 'granola-espresso',
        name: 'گرانولا اسپرسو',
        ingredients: 'اسپرسو، گرانولا، بستنی',
        price: 199,
        image: '/images/granola-espresso.jpg'
      },
      {
        id: 'con-panna',
        name: 'کن پانا',
        ingredients: 'اسپرسو، خامه',
        price: 171,
        image: '/images/con-panna.jpg'
      }
    ]
  },
  {
    id: 'hot-drinks',
    name: 'نوشیدنی گرم',
    icon: '🔥',
    items: [
      {
        id: 'hot-chocolate',
        name: 'شکلات گرم',
        ingredients: 'شکلات، شیر',
        price: 145,
        image: '/images/hot-chocolate.jpg'
      },
      {
        id: 'hot-tea',
        name: 'چای گرم',
        ingredients: 'چای',
        price: 95,
        image: '/images/hot-tea.jpg'
      }
    ]
  },
  {
    id: 'tea-herbal',
    name: 'چای و دمنوش',
    icon: '🫖',
    items: [
      {
        id: 'herbal-tea',
        name: 'دمنوش گیاهی',
        ingredients: 'گیاهان دمنوش',
        price: 115,
        image: '/images/herbal-tea.jpg'
      },
      {
        id: 'mint-tea',
        name: 'چای نعناع',
        ingredients: 'چای، نعناع',
        price: 105,
        image: '/images/mint-tea.jpg'
      }
    ]
  },
  {
    id: 'shakes-smoothies',
    name: 'شیک و اسموتی',
    icon: '🥤',
    items: [
      {
        id: 'fruit-smoothie',
        name: 'اسموتی میوه‌ای',
        ingredients: 'میوه‌های تازه، شیر، یخ',
        price: 165,
        image: '/images/fruit-smoothie.jpg'
      },
      {
        id: 'banana-shake',
        name: 'شیک موز',
        ingredients: 'موز، شیر، بستنی',
        price: 155,
        image: '/images/banana-shake.jpg'
      },
      {
        id: 'strawberry-shake',
        name: 'شیک توت‌فرنگی',
        ingredients: 'توت‌فرنگی، شیر، بستنی',
        price: 155,
        image: '/images/strawberry-shake.jpg'
      }
    ]
  },
  {
    id: 'cafe-bar',
    name: 'نگارا بار',
    icon: '🍹',
    items: [
      {
        id: 'mojito',
        name: 'موخیتو',
        ingredients: 'نعناع، لیمو، شکر، آب سوداگیر',
        price: 185,
        image: '/images/mojito.jpg'
      },
      {
        id: 'iced-latte',
        name: 'لاته یخی',
        ingredients: 'اسپرسو، شیر، یخ',
        price: 155,
        image: '/images/iced-latte.jpg'
      }
    ]
  },
  {
    id: 'cake',
    name: 'کیک',
    icon: '🍰',
    items: [
      {
        id: 'chocolate-cake',
        name: 'کیک شکلاتی',
        ingredients: 'شکلات، آرد، تخم‌مرغ، شیر',
        price: 185,
        image: '/images/chocolate-cake.jpg'
      },
      {
        id: 'vanilla-cake',
        name: 'کیک وانیلی',
        ingredients: 'وانیل، آرد، تخم‌مرغ، شیر',
        price: 175,
        image: '/images/vanilla-cake.jpg'
      },
      {
        id: 'cheesecake',
        name: 'چیزکیک',
        ingredients: 'پنیر کریم، آرد، شکر',
        price: 195,
        image: '/images/cheesecake.jpg'
      }
    ]
  }
];

