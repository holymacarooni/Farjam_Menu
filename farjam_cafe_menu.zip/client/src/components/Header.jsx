export default function Header() {
  return (
    <header className="bg-gradient-to-b from-amber-50 to-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4 py-8 text-center">
        {/* Café Name */}
        <h1 className="text-5xl font-bold text-amber-900 mb-2 text-right">فرجام کافه</h1>
        
        {/* Subtitle */}
        <p className="text-lg text-gray-600 text-right">منو کافه</p>
      </div>
    </header>
  );
}

